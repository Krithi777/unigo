"""
women_ride.py — Phase 3: Women-Only Ride search endpoints.

Endpoints:
  GET /rides/women-only/{community_id}   List women-only scheduled rides
  GET /rides/search/{community_id}       General ride search with optional women_only filter
"""

import logging
from typing import Optional

from fastapi import APIRouter, Query
from app.db.supabase_client import supabase

router = APIRouter()
logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
#  GET /rides/women-only/{community_id}
# --------------------------------------------------------------------------- #

@router.get("/women-only/{community_id}")
async def get_women_only_rides(community_id: str):
    """
    Return all scheduled women-only rides in the given community.
    Joins with users table to include driver name + reliability score.
    """
    result = (
        supabase.table("rides")
        .select(
            "id, pickup_address, dropoff_address, departure_time, "
            "seats_available, seats_total, women_only, optimized_route, "
            "users!rides_driver_id_fkey(id, name, reliability_score, gender)"
        )
        .eq("community_id", community_id)
        .eq("women_only", True)
        .eq("status", "scheduled")
        .gt("seats_available", 0)
        .order("departure_time")
        .execute()
    )

    rides = result.data or []
    logger.info(
        "Fetched %d women-only rides for community %s", len(rides), community_id
    )
    return {"rides": rides, "count": len(rides)}


# --------------------------------------------------------------------------- #
#  GET /rides/search/{community_id}
# --------------------------------------------------------------------------- #

@router.get("/search/{community_id}")
async def search_rides(
    community_id: str,
    women_only: Optional[bool] = Query(default=None, description="Filter for women-only rides"),
    limit: int = Query(default=20, ge=1, le=100),
):
    """
    General ride search within a community.
    Optionally filter by women_only=true.
    Returns scheduled rides with seats available, ordered by departure time.
    """
    query = (
        supabase.table("rides")
        .select(
            "id, pickup_lat, pickup_lng, pickup_address, "
            "dropoff_lat, dropoff_lng, dropoff_address, "
            "departure_time, seats_available, seats_total, women_only, "
            "users!rides_driver_id_fkey(id, name, reliability_score)"
        )
        .eq("community_id", community_id)
        .eq("status", "scheduled")
        .gt("seats_available", 0)
        .order("departure_time")
        .limit(limit)
    )

    if women_only is True:
        query = query.eq("women_only", True)
    elif women_only is False:
        # Explicitly requesting non-women-only rides
        query = query.eq("women_only", False)
    # If women_only is None, return all rides (no filter applied)

    result = query.execute()
    rides = result.data or []

    logger.info(
        "Search: %d rides in community %s (women_only=%s)",
        len(rides),
        community_id,
        women_only,
    )
    return {"rides": rides, "count": len(rides)}