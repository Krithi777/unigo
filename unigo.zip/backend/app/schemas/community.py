# Pydantic: CommunityCreate, CommunityJoin, CommunityOut
