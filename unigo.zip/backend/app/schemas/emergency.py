# Pydantic: EmergencyTrigger
