# Pydantic: PulseCheckin, PulseOut
