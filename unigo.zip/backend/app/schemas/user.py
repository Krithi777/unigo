# Pydantic: UserCreate, UserOut, EmergencyContactUpdate
