// POST /emergency/trigger (SOS)
