/**
 * ridesApi.ts — HTTP API client for UniGo rides endpoints.
 *
 * All functions correspond to backend/app/routers/rides.py and women_ride.py.
 */

import Constants from 'expo-constants';

const BASE_URL: string =
  (Constants.expoConfig?.extra?.API_BASE_URL as string) ||
  process.env.EXPO_PUBLIC_API_BASE_URL ||
  'http://localhost:8000';

// -------------------------------------------------------------------------- //
//  Types
// -------------------------------------------------------------------------- //

export interface CreateRidePayload {
  driver_id: string;
  community_id: string;
  pickup_lat: number;
  pickup_lng: number;
  pickup_address?: string;
  dropoff_lat: number;
  dropoff_lng: number;
  dropoff_address?: string;
  departure_time: string;   // ISO 8601
  seats_total: number;
  women_only: boolean;
}

export interface JoinRidePayload {
  rider_id: string;
  pickup_lat: number;
  pickup_lng: number;
  pickup_address?: string;
}

export interface Ride {
  id: string;
  driver_id: string;
  community_id: string;
  pickup_lat: number;
  pickup_lng: number;
  pickup_address?: string;
  dropoff_lat: number;
  dropoff_lng: number;
  dropoff_address?: string;
  departure_time: string;
  seats_total: number;
  seats_available: number;
  women_only: boolean;
  status: 'scheduled' | 'active' | 'completed' | 'cancelled';
  optimized_route?: object | null;
  users?: { name: string; reliability_score: number };
}

export interface RideRequest {
  id: string;
  ride_id: string;
  rider_id: string;
  pickup_lat: number;
  pickup_lng: number;
  pickup_address?: string;
  status: string;
  fare_share?: number;
  paid: boolean;
}

// -------------------------------------------------------------------------- //
//  Helper
// -------------------------------------------------------------------------- //

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options?.headers ?? {}) },
    ...options,
  });

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({ detail: res.statusText }));
    const message = errorBody?.detail || `HTTP ${res.status}`;
    throw new Error(message);
  }

  return res.json() as Promise<T>;
}

// -------------------------------------------------------------------------- //
//  Ride CRUD
// -------------------------------------------------------------------------- //

/** Phase 1 — Create a new ride (driver). */
export async function createRide(
  payload: CreateRidePayload
): Promise<{ ride: Ride }> {
  return apiFetch('/rides/create', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

/** Phase 1 — Rider joins a scheduled ride. Triggers RouteMorph. */
export async function joinRide(
  rideId: string,
  payload: JoinRidePayload
): Promise<{ ride_request: RideRequest; optimized_route: object | null }> {
  return apiFetch(`/rides/${rideId}/join`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

/** Phase 2 — Driver cancels their ride. */
export async function cancelRide(
  rideId: string,
  driverId: string
): Promise<{
  cancelled: boolean;
  is_last_minute: boolean;
  stranded_count: number;
  reassigned_count: number;
}> {
  return apiFetch(`/rides/${rideId}/cancel?driver_id=${driverId}`, {
    method: 'POST',
  });
}

/** Phase 4 — Driver starts the ride. */
export async function startRide(
  rideId: string,
  driverId: string
): Promise<{ ride: Ride }> {
  return apiFetch(`/rides/${rideId}/start?driver_id=${driverId}`, {
    method: 'POST',
  });
}

/** Phase 4 — Driver completes/ends the ride. */
export async function completeRide(
  rideId: string,
  driverId: string
): Promise<{ completed: boolean; ride_id: string }> {
  return apiFetch(`/rides/${rideId}/complete?driver_id=${driverId}`, {
    method: 'POST',
  });
}

/** Accept or reject a rider's request (driver). */
export async function updateRideRequest(
  rideId: string,
  reqId: string,
  newStatus: 'accepted' | 'rejected'
): Promise<{ ride_request_id: string; status: string }> {
  return apiFetch(`/rides/${rideId}/request/${reqId}`, {
    method: 'PATCH',
    body: JSON.stringify({ status: newStatus }),
  });
}

/** Get upcoming rides for a user (as driver or rider). */
export async function getUpcomingRides(
  userId: string
): Promise<{ driver_rides: Ride[]; rider_rides: Ride[] }> {
  return apiFetch(`/rides/upcoming/${userId}`);
}

// -------------------------------------------------------------------------- //
//  Phase 3 — Ride search (women_ride.py)
// -------------------------------------------------------------------------- //

/** Search rides in a community with optional women-only filter. */
export async function searchRides(
  communityId: string,
  womenOnly?: boolean
): Promise<{ rides: Ride[]; count: number }> {
  const params = new URLSearchParams();
  if (womenOnly !== undefined) {
    params.set('women_only', String(womenOnly));
  }
  const qs = params.toString() ? `?${params}` : '';
  return apiFetch(`/rides/search/${communityId}${qs}`);
}

/** Get only women-only rides in a community. */
export async function getWomenOnlyRides(
  communityId: string
): Promise<{ rides: Ride[]; count: number }> {
  return apiFetch(`/rides/women-only/${communityId}`);
}